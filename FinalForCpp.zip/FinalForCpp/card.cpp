#include "card.h"

Card::Card() {
	name = "Monopoly Card";
}

void Card::setAmount(int num)
{
}

void Card::setCardText(std::string text1)
{
}

void Card::cardAction(Player& bank1, Player& player1)
{
}

std::string Card::getCardText()
{
	return "";
}
